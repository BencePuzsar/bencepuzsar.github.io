// Your JavaScript code goes here

console.log('Hello from Javascript file!');

console.log('Hello again from Javascript file');